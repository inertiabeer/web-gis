// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
define({
'themes/FoldableTheme/widgets/HeaderController/setting/nls/strings':{"group":"Имя","openAll":"Открыть все на панели","dropDown":"Показывать в ниспадающем меню","noGroup":"Нет групповой настройки виджетов.","groupSetLabel":"Задать групповые свойства виджетов","_localized":{}}
});