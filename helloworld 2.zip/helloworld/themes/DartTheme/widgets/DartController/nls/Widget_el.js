// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/DartTheme/widgets/DartController/nls/strings":{_widgetLabel:"\u03a3\u03c4\u03bf\u03c7\u03b5\u03af\u03bf \u03b5\u03bb\u03ad\u03b3\u03c7\u03bf\u03c5 \u03c4\u03bf\u03c5 Dart",_localized:{}}});