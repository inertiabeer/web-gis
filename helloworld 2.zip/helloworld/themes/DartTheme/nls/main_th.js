// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/DartTheme/nls/strings":{_themeLabel:"\u0e14\u0e32\u0e23\u0e4c\u0e17\u0e18\u0e35\u0e21",_layout_default:"\u0e42\u0e04\u0e23\u0e07\u0e23\u0e48\u0e32\u0e07\u0e15\u0e31\u0e49\u0e07\u0e15\u0e49\u0e19",_localized:{}}});