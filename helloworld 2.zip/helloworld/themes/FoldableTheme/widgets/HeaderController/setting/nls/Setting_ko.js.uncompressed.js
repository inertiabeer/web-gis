// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
define({
'themes/FoldableTheme/widgets/HeaderController/setting/nls/strings':{"group":"이름","openAll":"패널의 모든 항목 열기","dropDown":"드롭다운 메뉴에 표시","noGroup":"위젯 그룹 세트가 없습니다.","groupSetLabel":"위젯 그룹 등록정보 설정","_localized":{}}
});