// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/BoxTheme/widgets/BoxController/nls/strings":{_widgetLabel:"\u30dc\u30c3\u30af\u30b9 \u30b3\u30f3\u30c8\u30ed\u30fc\u30e9\u30fc",_localized:{}}});