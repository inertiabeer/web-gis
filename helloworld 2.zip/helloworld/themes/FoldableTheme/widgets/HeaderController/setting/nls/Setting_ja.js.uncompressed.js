// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
define({
'themes/FoldableTheme/widgets/HeaderController/setting/nls/strings':{"group":"名前","openAll":"すべてをパネルで開く","dropDown":"ドロップダウン メニューに表示","noGroup":"ウィジェット グループ セットがありません。","groupSetLabel":"ウィジェット グループ プロパティの設定","_localized":{}}
});