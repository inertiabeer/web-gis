// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
define({
'themes/FoldableTheme/widgets/HeaderController/setting/nls/strings':{"group":"Nazwa","openAll":"Otwórz wszystko w panelu","dropDown":"Pokaż w menu rozwijanym","noGroup":"Brak skonfigurowanej grupy widżetów","groupSetLabel":"Skonfiguruj właściwości grupy widżetów","_localized":{}}
});