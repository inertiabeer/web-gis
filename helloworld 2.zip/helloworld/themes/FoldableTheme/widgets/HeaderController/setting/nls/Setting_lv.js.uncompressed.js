// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
define({
'themes/FoldableTheme/widgets/HeaderController/setting/nls/strings':{"group":"Nosaukums","openAll":"Atvērt visu panelī","dropDown":"Rādīt nolaižamajā izvēlnē","noGroup":"Nav iestatīta logrīku grupa.","groupSetLabel":"Iestatīt logrīku grupas rekvizītus","_localized":{}}
});