// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
define({
'themes/FoldableTheme/widgets/HeaderController/setting/nls/strings':{"group":"Navn","openAll":"Åbn alle i panelet","dropDown":"Vis i rullemenuen","noGroup":"Der er ingen widget-gruppe angivet.","groupSetLabel":"Angiv egenskaber for widget-grupper","_localized":{}}
});