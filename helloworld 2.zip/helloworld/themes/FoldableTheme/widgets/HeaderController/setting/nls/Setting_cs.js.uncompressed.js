// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
define({
'themes/FoldableTheme/widgets/HeaderController/setting/nls/strings':{"group":"Název","openAll":"Otevřít vše v panelu","dropDown":"Zobrazit v rozbalovací nabídce","noGroup":"Není nastavena žádná skupina widgetů.","groupSetLabel":"Nastavit vlastnosti skupin widgetů","_localized":{}}
});